# Vera — magicpin AI Challenge Submission

## Approach
A deterministic, context-grounded message engine. It stores versioned category/merchant/customer/trigger contexts, selects active triggers on `/v1/tick`, applies consent and suppression gates, composes category- and merchant-specific copy, and maintains conversation state for `/v1/reply`.

No external LLM is required for correctness or local judging, which keeps latency and same-input determinism predictable. The composition layer is isolated in `app/engine.py` so an optional structured-output LLM can be added later without moving eligibility/state logic into the model.

## Run
```bash
python -m pip install -r requirements.txt
uvicorn bot:app --host 0.0.0.0 --port 8080
```

## Endpoints
- `GET /v1/healthz`
- `GET /v1/metadata`
- `POST /v1/context`
- `POST /v1/tick`
- `POST /v1/reply`

## Official dataset generator
```bash
python dataset/generate_dataset.py --seed-dir dataset --out dataset/expanded
```

## Local simulator
In another terminal, with the bot running:
```bash
export BOT_URL=http://localhost:8080
python judge_simulator.py --scenario warmup
python judge_simulator.py --scenario phase2_short
python judge_simulator.py --scenario all
```
The simulator's LLM scoring requires one of its configured provider keys; the operational scenarios do not.

## Design choices
- Exact context version replacement and stale-version rejection.
- Trigger suppression by `suppression_key` within the running process.
- Customer opt-in gate for proactive customer sends.
- Customer-facing `send_as=merchant_on_behalf`; merchant-facing `send_as=vera`.
- One primary CTA; no invented offers, statistics, competitors, or customer behavior.
- Reply classifier handles acceptance, commitment, deferral, opt-out, questions, and repeated auto-replies.

## Deployment
Use any service that exposes the container on a public HTTP/HTTPS URL. The Dockerfile starts Uvicorn on `$PORT`; submit the resulting base URL with `/v1/*` routes to magicpin.

## Tradeoff
The implementation deliberately prefers deterministic grounded composition over generative creativity. This reduces hallucination and latency risk, while leaving the composer isolated for a future structured-output model.
