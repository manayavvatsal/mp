import os, time, re
from datetime import datetime, timezone
from threading import RLock
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from app.engine import compose

app=FastAPI(title="Vera Merchant AI Assistant", version="1.0.0")
START=time.time(); LOCK=RLock()
contexts={}; conversations={}; sent_keys=set(); sent_bodies={}; auto_reply_count=0

class ContextBody(BaseModel):
    scope:str
    context_id:str
    version:int
    payload:dict[str,Any]
    delivered_at:str
class TickBody(BaseModel):
    now:str
    available_triggers:list[str]=Field(default_factory=list)
class ReplyBody(BaseModel):
    conversation_id:str
    merchant_id:str|None=None
    customer_id:str|None=None
    from_role:str
    message:str
    received_at:str
    turn_number:int

def counts():
    out={"category":0,"merchant":0,"customer":0,"trigger":0}
    for scope,_ in contexts: out[scope]=out.get(scope,0)+1
    return out

def get(scope,cid):
    x=contexts.get((scope,cid)); return x["payload"] if x else None

def action_valid(a):
    return all(k in a for k in ["conversation_id","merchant_id","send_as","trigger_id","body","cta","suppression_key","rationale"])

@app.get('/v1/healthz')
def healthz():
    return {"status":"ok","uptime_seconds":int(time.time()-START),"contexts_loaded":counts()}

@app.get('/v1/metadata')
def metadata():
    return {"team_name":os.getenv("TEAM_NAME","Vera Deterministic Engine"),"team_members":[x.strip() for x in os.getenv("TEAM_MEMBERS","Challenge Submission").split(',') if x.strip()],"model":"deterministic-rule-engine","approach":"context-grounded deterministic decision engine with optional LLM-free composition","contact_email":os.getenv("CONTACT_EMAIL",""),"version":"1.0.0","submitted_at":datetime.now(timezone.utc).isoformat()}

@app.post('/v1/context')
def push_context(body:ContextBody):
    if body.scope not in {"category","merchant","customer","trigger"}:
        raise HTTPException(400, detail={"accepted":False,"reason":"invalid_scope","details":"scope must be category, merchant, customer, or trigger"})
    key=(body.scope,body.context_id)
    with LOCK:
        cur=contexts.get(key)
        if cur and cur["version"]>=body.version:
            return {"accepted":False,"reason":"stale_version","current_version":cur["version"]}
        contexts[key]={"version":body.version,"payload":body.payload}
    return {"accepted":True,"ack_id":f"ack_{body.context_id}_v{body.version}","stored_at":datetime.now(timezone.utc).isoformat()}

def make_action(tid,trg,merchant,category,customer):
    comp=compose(category,merchant,trg,customer)
    mid=trg.get('merchant_id'); cid=trg.get('customer_id')
    conv=f"conv_{mid}_{tid}"
    return {"conversation_id":conv,"merchant_id":mid,"customer_id":cid,"send_as":comp["send_as"],"trigger_id":tid,"template_name":"vera_context_v1","template_params":[merchant.get('identity',{}).get('name',''), trg.get('kind',''), comp.get('cta','')],"body":comp["body"],"cta":comp["cta"],"suppression_key":comp["suppression_key"],"rationale":comp["rationale"]}

@app.post('/v1/tick')
def tick(body:TickBody):
    actions=[]
    with LOCK:
        for tid in body.available_triggers[:20]:
            trg=get('trigger',tid)
            if not trg: continue
            mid=trg.get('merchant_id'); merchant=get('merchant',mid)
            if not merchant: continue
            cat=get('category',merchant.get('category_slug'))
            if not cat: continue
            cid=trg.get('customer_id'); customer=get('customer',cid) if cid else None
            # customer consent gate
            if customer and not customer.get('preferences',{}).get('reminder_opt_in', True): continue
            skey=trg.get('suppression_key')
            if skey and skey in sent_keys: continue
            action=make_action(tid,trg,merchant,cat,customer)
            if not action_valid(action): continue
            actions.append(action)
            if skey: sent_keys.add(skey)
            sent_bodies.setdefault(action['conversation_id'],set()).add(action['body'])
            conversations.setdefault(action['conversation_id'],[]).append({"role":"vera","message":action['body'],"trigger_id":tid})
    return {"actions":actions}

AUTO_REPLIES={"thank you for contacting us! our team will respond shortly.","thanks for contacting us. we will get back to you shortly."}

def intent(msg):
    m=msg.lower().strip()
    if any(x in m for x in ["stop messaging","stop","unsubscribe","not interested","no thanks","remove me"]): return 'negative'
    if m in AUTO_REPLIES or ("thank you for contacting us" in m and "respond shortly" in m): return 'auto'
    if any(x in m for x in ["ok lets do it","ok let's do it","let's do it","lets do it","yes do it","go ahead","proceed","do it"]): return 'commit'
    if any(x in m for x in ["yes","sure","send it","send me","interested","sounds good","please do"]): return 'positive'
    if any(x in m for x in ["later","tomorrow","next week","give me time","not now"]): return 'wait'
    return 'question'

@app.post('/v1/reply')
def reply(body:ReplyBody):
    global auto_reply_count
    with LOCK:
        hist=conversations.setdefault(body.conversation_id,[])
        hist.append({"role":body.from_role,"message":body.message,"turn":body.turn_number})
        recent=[h.get('message','').strip().lower() for h in hist[-5:] if h.get('role')==body.from_role]
        if any("thank you for contacting us" in x and "respond shortly" in x for x in recent):
            auto_reply_count += 1
            if auto_reply_count >= 2:
                return {"action":"end","rationale":"Repeated canned auto-reply detected across turns; ending to avoid duplicate outreach."}
            return {"action":"wait","wait_seconds":1800,"rationale":"Canned auto-reply detected; waiting rather than sending another message immediately."}
        kind=intent(body.message)
        if kind in {'negative','auto'}:
            return {"action":"end","rationale":"Conversation state indicates opt-out, disinterest, or repeated automated reply; no further outreach."}
        if kind=='wait':
            return {"action":"wait","wait_seconds":1800,"rationale":"Merchant asked to defer; backing off rather than adding another CTA immediately."}
        if kind=='commit':
            return {"action":"send","body":"Done — moving to the next step from the context already shared. I’ll keep it to the agreed action and won’t add unsupported details.","cta":"open_ended","rationale":"Explicit commitment detected; switching from qualification to execution."}
        if kind=='positive':
            return {"action":"send","body":"Absolutely — I’ll take the next step using the context already provided. If anything needs your input, I’ll keep it to one concrete question.","cta":"open_ended","rationale":"Positive acceptance detected; advancing without unnecessary re-qualification."}
        return {"action":"send","body":"Got it. I’ll keep this tied to the original request and the context already supplied. Tell me the one detail you want clarified, and I’ll address that directly.","cta":"open_ended","rationale":"Unresolved question detected; keeping the conversation on-mission and requesting only the missing detail."}
